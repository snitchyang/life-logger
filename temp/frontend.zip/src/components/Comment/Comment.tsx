import { type IComment } from "../../interface";
import { Text } from "@rneui/base";
import { View } from "react-native";

interface Comment {
  comment: IComment;
}

export const Comment = ({ comment }: Comment) => {
  return (
    <View>
      <View style={{ flexDirection: "row" }}>
        <Text style={{ paddingRight: 10, fontSize: 16 }}>
          {comment.user.username}
        </Text>
        <Text
          style={{
            fontSize: 12,
            paddingTop: 2,
          }}
        >
          {comment.date.getDate()}
          {"前"}
        </Text>
      </View>
      <Text>{comment.content}</Text>
    </View>
  );
};
