import { Text, View } from "react-native";
import * as React from "react";

export const DiscoveryPage = () => {
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <Text>this is the content page</Text>
    </View>
  );
};
