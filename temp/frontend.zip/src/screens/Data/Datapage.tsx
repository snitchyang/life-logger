import React, { Text, View } from "react-native";

export const DataPage = (): JSX.Element => {
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <Text>this is the data page</Text>
    </View>
  );
};
