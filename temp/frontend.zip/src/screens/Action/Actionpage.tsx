import { Text, View } from "react-native";
import * as React from "react";

export const ActionPage = () => {
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <Text>this is the action page</Text>
    </View>
  );
};
