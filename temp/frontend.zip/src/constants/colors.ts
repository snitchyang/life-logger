export default {
  primary: "black",
  gray: "#666666",
  black: "#000000",
  white: "#FFFFFF",
  card: "white",
  warning: "#E03D2E",
};
